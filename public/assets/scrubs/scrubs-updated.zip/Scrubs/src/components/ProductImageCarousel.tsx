import { useEffect, useRef, useState } from 'react';

export default function ProductImageCarousel({
  images,
  alt,
  intervalMs = 3500,
  className = '',
}: {
  images: string[];
  alt: string;
  intervalMs?: number;
  className?: string;
}) {
  const list = images && images.length > 0 ? images : [];
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (list.length <= 1 || paused) return;
    timerRef.current = setInterval(() => {
      setIndex(i => (i + 1) % list.length);
    }, intervalMs);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [list.length, paused, intervalMs]);

  if (list.length === 0) {
    return <div className={`relative overflow-hidden ${className}`} />;
  }

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {list.map((url, i) => {
        const isActive = i === index;
        return (
          <img
            key={url + i}
            src={url}
            alt={alt}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-in-out"
            style={{
              transform: isActive ? 'translateY(0)' : 'translateY(-100%)',
              opacity: isActive ? 1 : 0,
              zIndex: isActive ? 1 : 0,
            }}
          />
        );
      })}

      {list.length > 1 && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
          {list.map((_, i) => (
            <button
              key={i}
              onClick={(e) => {
                e.stopPropagation();
                setIndex(i);
              }}
              aria-label={`صورة ${i + 1}`}
              className="w-1.5 h-1.5 rounded-full transition-all"
              style={{
                backgroundColor: i === index ? '#fff' : 'rgba(255,255,255,0.5)',
                transform: i === index ? 'scale(1.4)' : 'scale(1)',
                boxShadow: '0 0 2px rgba(0,0,0,0.4)',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
